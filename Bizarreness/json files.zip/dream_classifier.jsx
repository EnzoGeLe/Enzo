import { useState, useRef, useCallback } from "react";

const SYSTEM_PROMPT = `You are an expert classifier trained to distinguish between DREAM REPORTS and WAKEFULNESS REPORTS based on their semantic and linguistic content.

A DREAM REPORT is a verbal account of a subjective conscious experience occurring during sleep, recorded immediately upon awakening. Key features:
- Narrative set in a past/imagined context, often introduced with "Ero..." (I was...) or similar past-tense immersive openings
- Bizarre, impossible, or unusual events (e.g. wine cut into slices, flying, unknown places)
- Characters appearing/disappearing without explanation
- Scene discontinuities, sudden transitions
- Emotional vividness with unclear causal logic
- References to waking up or "this is a dream"
- Dreamlike imagery (surreal settings, distorted physics)

A WAKEFULNESS REPORT is a verbal account of thoughts, experiences, or mental content occurring during normal waking life. Key features:
- Grounded in real, plausible, everyday activities
- Present-tense or reflective tone about daily events
- Coherent causal logic and normal time flow
- Planning, worrying, remembering real events
- References to real-world context (work, family, schedule)
- Mundane emotional states about real situations

You will receive multiple reports at once (in Italian). For EACH report, return a JSON object. Respond ONLY with a JSON array, no preamble, no markdown, no explanation outside the JSON.

Format exactly:
[
  {"id": "<CodeRef>", "row": <rowIndex>, "label": "DREAM" or "WAKEFULNESS", "confidence": <0-100>, "justification": "<1-2 sentence rationale in English>"},
  ...
]`;

const BATCH_SIZE = 8;

export default function DreamClassifier() {
  const [reports, setReports] = useState([]);
  const [results, setResults] = useState([]);
  const [processing, setProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [total, setTotal] = useState(0);
  const [errors, setErrors] = useState([]);
  const [fileLoaded, setFileLoaded] = useState(false);
  const [fileName, setFileName] = useState("");
  const [paused, setPaused] = useState(false);
  const pausedRef = useRef(false);
  const fileInputRef = useRef();

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const data = JSON.parse(ev.target.result);
        setReports(data);
        setFileLoaded(true);
        setResults([]);
        setProgress(0);
        setErrors([]);
      } catch {
        alert("Invalid JSON file. Please upload the reports JSON file.");
      }
    };
    reader.readAsText(file);
  };

  const classifyBatch = async (batch) => {
    const userContent = batch
      .map((r, i) => `Report ${i + 1} [CodeRef: ${r.CodeRef}, row: ${r.rowIndex}]:\n${r.txt_cleaned}`)
      .join("\n\n---\n\n");

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        system: SYSTEM_PROMPT,
        messages: [{ role: "user", content: `Classify these ${batch.length} reports:\n\n${userContent}` }],
      }),
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.error?.message || "API error");

    const text = data.content.map((b) => b.text || "").join("");
    const clean = text.replace(/```json|```/g, "").trim();
    return JSON.parse(clean);
  };

  const startClassification = useCallback(async () => {
    if (!reports.length) return;
    setProcessing(true);
    setPaused(false);
    pausedRef.current = false;
    setTotal(reports.length);
    setProgress(0);
    setErrors([]);

    const allResults = [...results];
    const alreadyDone = new Set(results.map((r) => r.row));
    const remaining = reports.filter((r) => !alreadyDone.has(r.rowIndex));

    for (let i = 0; i < remaining.length; i += BATCH_SIZE) {
      while (pausedRef.current) {
        await new Promise((res) => setTimeout(res, 300));
      }

      const batch = remaining.slice(i, i + BATCH_SIZE);
      try {
        const batchResults = await classifyBatch(batch);
        allResults.push(...batchResults);
        setResults([...allResults]);
        setProgress(allResults.length);
      } catch (err) {
        const errorEntry = { batch: i, error: err.message, ids: batch.map((r) => r.CodeRef) };
        setErrors((prev) => [...prev, errorEntry]);
        // Add error placeholders
        batch.forEach((r) => {
          allResults.push({ id: r.CodeRef, row: r.rowIndex, label: "ERROR", confidence: 0, justification: err.message });
        });
        setResults([...allResults]);
        setProgress(allResults.length);
        await new Promise((res) => setTimeout(res, 2000));
      }

      if (i + BATCH_SIZE < remaining.length) {
        await new Promise((res) => setTimeout(res, 400));
      }
    }

    setProcessing(false);
  }, [reports, results]);

  const togglePause = () => {
    pausedRef.current = !pausedRef.current;
    setPaused(pausedRef.current);
  };

  const downloadCSV = () => {
    const sorted = [...results].sort((a, b) => a.row - b.row);
    const header = "row,CodeRef,label,confidence,justification";
    const rows = sorted.map((r) => {
      const justification = `"${(r.justification || "").replace(/"/g, "'")}"`;
      return `${r.row},${r.id},${r.label},${r.confidence},${justification}`;
    });
    const csv = [header, ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "dream_classification_results.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  const pct = total > 0 ? Math.round((progress / total) * 100) : 0;
  const dreamCount = results.filter((r) => r.label === "DREAM").length;
  const wakeCount = results.filter((r) => r.label === "WAKEFULNESS").length;

  const sorted = [...results].sort((a, b) => a.row - b.row);

  return (
    <div style={{ fontFamily: "Arial, sans-serif", maxWidth: 900, margin: "0 auto", padding: 24, backgroundColor: "#0f1117", color: "#e2e8f0", minHeight: "100vh" }}>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 22, fontWeight: 700, color: "#a78bfa", margin: 0 }}>🧠 Dream / Wakefulness Classifier</h1>
        <p style={{ color: "#94a3b8", marginTop: 6, fontSize: 14 }}>Upload the <code style={{ background: "#1e293b", padding: "2px 6px", borderRadius: 4 }}>reports_for_classifier.json</code> file, then run classification.</p>
      </div>

      {/* File Upload */}
      <div style={{ background: "#1e293b", borderRadius: 12, padding: 20, marginBottom: 20, border: fileLoaded ? "1px solid #4ade80" : "1px dashed #475569" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <button
            onClick={() => fileInputRef.current.click()}
            style={{ background: "#6d28d9", color: "white", border: "none", borderRadius: 8, padding: "10px 18px", cursor: "pointer", fontWeight: 600, fontSize: 14 }}
          >
            📂 Upload JSON
          </button>
          <input ref={fileInputRef} type="file" accept=".json" onChange={handleFileUpload} style={{ display: "none" }} />
          {fileLoaded ? (
            <div style={{ color: "#4ade80", fontSize: 14 }}>
              ✅ <strong>{fileName}</strong> — {reports.length.toLocaleString()} reports loaded
            </div>
          ) : (
            <span style={{ color: "#64748b", fontSize: 14 }}>No file selected</span>
          )}
        </div>
      </div>

      {/* Controls */}
      {fileLoaded && (
        <div style={{ display: "flex", gap: 12, marginBottom: 20, flexWrap: "wrap" }}>
          {!processing && progress < total && (
            <button
              onClick={startClassification}
              style={{ background: "#7c3aed", color: "white", border: "none", borderRadius: 8, padding: "10px 20px", cursor: "pointer", fontWeight: 700, fontSize: 14 }}
            >
              ▶ {progress > 0 ? "Resume" : "Start"} Classification
            </button>
          )}
          {processing && (
            <button
              onClick={togglePause}
              style={{ background: paused ? "#16a34a" : "#b45309", color: "white", border: "none", borderRadius: 8, padding: "10px 20px", cursor: "pointer", fontWeight: 700, fontSize: 14 }}
            >
              {paused ? "▶ Resume" : "⏸ Pause"}
            </button>
          )}
          {results.length > 0 && (
            <button
              onClick={downloadCSV}
              style={{ background: "#0f766e", color: "white", border: "none", borderRadius: 8, padding: "10px 20px", cursor: "pointer", fontWeight: 700, fontSize: 14 }}
            >
              ⬇ Download CSV ({results.length} rows)
            </button>
          )}
          {results.length > 0 && !processing && (
            <button
              onClick={() => { setResults([]); setProgress(0); }}
              style={{ background: "#1e293b", color: "#94a3b8", border: "1px solid #475569", borderRadius: 8, padding: "10px 20px", cursor: "pointer", fontSize: 14 }}
            >
              🗑 Reset
            </button>
          )}
        </div>
      )}

      {/* Progress */}
      {total > 0 && (
        <div style={{ background: "#1e293b", borderRadius: 12, padding: 16, marginBottom: 20 }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8, fontSize: 13, color: "#94a3b8" }}>
            <span>{processing ? (paused ? "⏸ Paused" : "⚡ Processing...") : progress >= total ? "✅ Complete" : "Ready"}</span>
            <span>{progress} / {total} ({pct}%)</span>
          </div>
          <div style={{ background: "#0f172a", borderRadius: 8, height: 8, overflow: "hidden" }}>
            <div style={{ width: `${pct}%`, height: "100%", background: "linear-gradient(90deg, #7c3aed, #4ade80)", transition: "width 0.3s" }} />
          </div>
          {results.length > 0 && (
            <div style={{ display: "flex", gap: 24, marginTop: 10, fontSize: 13 }}>
              <span style={{ color: "#818cf8" }}>💤 Dream: <strong>{dreamCount}</strong></span>
              <span style={{ color: "#34d399" }}>☀ Wakefulness: <strong>{wakeCount}</strong></span>
              {errors.length > 0 && <span style={{ color: "#f87171" }}>⚠ Errors: <strong>{errors.length}</strong></span>}
            </div>
          )}
        </div>
      )}

      {/* Results Table */}
      {sorted.length > 0 && (
        <div style={{ background: "#1e293b", borderRadius: 12, overflow: "hidden" }}>
          <div style={{ padding: "12px 16px", borderBottom: "1px solid #334155", fontSize: 13, color: "#94a3b8" }}>
            Recent classifications (showing last 50)
          </div>
          <div style={{ maxHeight: 420, overflowY: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
              <thead>
                <tr style={{ background: "#0f172a", position: "sticky", top: 0 }}>
                  <th style={{ padding: "8px 12px", textAlign: "left", color: "#64748b", fontWeight: 600 }}>Row</th>
                  <th style={{ padding: "8px 12px", textAlign: "left", color: "#64748b", fontWeight: 600 }}>CodeRef</th>
                  <th style={{ padding: "8px 12px", textAlign: "left", color: "#64748b", fontWeight: 600 }}>Label</th>
                  <th style={{ padding: "8px 12px", textAlign: "left", color: "#64748b", fontWeight: 600 }}>Conf.</th>
                  <th style={{ padding: "8px 12px", textAlign: "left", color: "#64748b", fontWeight: 600 }}>Justification</th>
                </tr>
              </thead>
              <tbody>
                {sorted.slice(-50).reverse().map((r, i) => (
                  <tr key={i} style={{ borderTop: "1px solid #1e293b", background: i % 2 === 0 ? "#1a2540" : "#1e293b" }}>
                    <td style={{ padding: "7px 12px", color: "#64748b" }}>{r.row}</td>
                    <td style={{ padding: "7px 12px", color: "#a78bfa", fontWeight: 600 }}>{r.id}</td>
                    <td style={{ padding: "7px 12px" }}>
                      <span style={{
                        background: r.label === "DREAM" ? "#312e81" : r.label === "WAKEFULNESS" ? "#064e3b" : "#450a0a",
                        color: r.label === "DREAM" ? "#818cf8" : r.label === "WAKEFULNESS" ? "#34d399" : "#f87171",
                        padding: "2px 8px", borderRadius: 4, fontWeight: 700, fontSize: 11
                      }}>
                        {r.label === "DREAM" ? "💤 DREAM" : r.label === "WAKEFULNESS" ? "☀ WAKE" : "⚠ ERROR"}
                      </span>
                    </td>
                    <td style={{ padding: "7px 12px", color: r.confidence >= 80 ? "#4ade80" : r.confidence >= 60 ? "#fbbf24" : "#f87171" }}>
                      {r.confidence}%
                    </td>
                    <td style={{ padding: "7px 12px", color: "#94a3b8", fontSize: 12, maxWidth: 300 }}>{r.justification}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
